close all; clear all; clc;    % Clean Up Workspace
%--------------------------Load first data set----------------------------%
load('Pendulum_Data_1')
%-----------------------Build Data matrix---------------------------------%
Data = [POUT;QOUT]; %velocity and position
comb = nchoosek(1:8,2);
Data = [Data;Data.^2;Data(comb(:,1),:).*Data(comb(:,2),:)];
%-----------------------Perform DMD---------------------------------------%
X = Data(:,1:end - 1);
Y = Data(:,2:end);
[ ProjectedModes,DEv,ExactModes,Norm ] = Exact_DMD(X,Y);
%---------------------Freq & Growth rates---------------------------------%
Growth = real(log(DEv)./(TOUT(2) - TOUT(1)));
freq = imag(log(DEv)./(TOUT(2) - TOUT(1)))/2/pi;
plot(Growth, freq,'.b')
%---------------------Nonlinear Pend Freq---------------------------------%
F = zeros(4,1);
F(1) = 1/0;
Ep = 4;
E0 = POUT(3:4,1).^2 + Ep*sin(QOUT(3:4,1)/2).^2;
k = sqrt(E0/Ep);
x = 1/k;
K = ellipticK(x);
T = 2*x.*K;
F(3:4) = 1./T;

E0 = POUT(2,1).^2 + Ep*sin(QOUT(2,1)/2).^2;
k = sqrt(E0/Ep);
K = ellipticK(k);
T = 4*K;
F(2) = 1./T;
F









